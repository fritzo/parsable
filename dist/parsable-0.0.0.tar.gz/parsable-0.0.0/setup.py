from setuptools import setup, find_packages

setup(
    name='parsable',
    packages=find_packages(),
    py_modules=['parsable']
)
